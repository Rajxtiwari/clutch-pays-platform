import { Password } from "@convex-dev/auth/providers/Password";
import { DataModel } from "../_generated/dataModel";

export const CustomPasswordProvider = Password<DataModel>({
  profile(params) {
    return {
      email: params.email as string,
      name: params.username as string,
      username: params.username as string,
      dateOfBirth: params.dateOfBirth as string,
      verificationLevel: "unverified",
      walletBalance: 0,
      totalMatches: 0,
      totalWins: 0,
      totalEarnings: 0,
      isProfilePrivate: false,
    };
  },
});
