import { convexAuth } from "@convex-dev/auth/server";
import { Password } from "@convex-dev/auth/providers/Password";
import { DataModel } from "../_generated/dataModel";

const CustomPassword = Password<DataModel>({
  profile(params) {
    return {
      email: params.email as string,
      name: params.username as string,
      // Store additional fields
      username: params.username as string,
      dateOfBirth: params.dateOfBirth as string,
      verificationLevel: "pending_email",
      walletBalance: 0,
      totalMatches: 0,
      totalWins: 0,
      totalEarnings: 0,
      isProfilePrivate: false,
    };
  },
});

export default CustomPassword;
