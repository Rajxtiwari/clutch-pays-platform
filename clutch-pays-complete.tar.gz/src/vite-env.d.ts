/// <reference types="vite/client" />

declare module '@zumer/snapdom';
