export default {
  providers: [
    {
      domain: process.env.CONVEX_SITE_URL || "https://smooth-states-grab-lazily.vly.sh",
      applicationID: "convex",
    },
  ],
};